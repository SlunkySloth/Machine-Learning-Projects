"""Educational diabetes classification project."""
